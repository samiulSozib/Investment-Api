// services/investmentRequestService.js

const db = require('../database/db');
const { Op } = require('sequelize');

// Create a new investment request
const createInvestmentRequest = async ({ user_id, business_name, description, requested_amount, proposed_share,files }) => {
    const transaction = await db.sequelize.transaction();

    try {
        // Check if user exists
        const user = await db.User.findByPk(user_id, { transaction });
        if (!user) {
            throw new Error('User not found');
        }

        // Create the investment request
        const newRequest = await db.InvestmentRequest.create({
            user_id,
            business_name,
            description,
            requested_amount,
            proposed_share,
            status: 'pending',
        }, { transaction });

        // Save the images associated with the investment request
        if (files && files.length > 0) {
            const imageEntries = files.map(file => ({
                entry_type: 'investmentRequest',
                foreign_key_id: newRequest.id,
                image_url: `${process.env.base_url}/uploads/${file.filename}`
            }));
            //console.log(imageEntries)
            await db.Image.bulkCreate(imageEntries, { transaction });
        }

        // Return the investment request with associated images
        const createdRequest = await db.InvestmentRequest.findByPk(newRequest.id, {
            include: [{
                model: db.Image,
                as: 'investment_request_images',
                where: { entry_type: 'investmentRequest' },
                required: false // Left join to include images only if they exist
            }],
            transaction
        });

        await transaction.commit();
        return createdRequest;
    } catch (error) {
        await transaction.rollback();
        throw error;
    }
};

// Update an existing investment request
const updateInvestmentRequest = async (request_id, { business_name, description, requested_amount, proposed_share, status,files }) => {
    const transaction = await db.sequelize.transaction();

    try {
        const request = await db.InvestmentRequest.findByPk(request_id, { transaction });
        if (!request) {
            throw new Error('Investment request not found');
        }

        // Update the request details
        await db.InvestmentRequest.update(
            { business_name, description, requested_amount, proposed_share, status },
            { where: { id: request_id }, transaction }
        );

        if (files && files.length > 0) {
            // Optionally, delete old images associated with the investment request
            await db.Image.destroy({
                where: {
                    entry_type: 'investmentRequest',
                    foreign_key_id: request_id
                },
                transaction
            });

            // Save new images
            const imageEntries = files.map(file => ({
                entry_type: 'investmentRequest',
                foreign_key_id: request_id,
                image_url: `${process.env.base_url}/uploads/${file.filename}`
            }));
            await db.Image.bulkCreate(imageEntries, { transaction });
        }


         const updatedRequest = await db.InvestmentRequest.findByPk(request_id, {
            include: [{
                model: db.Image,
                as: 'investment_request_images',
                where: { entry_type: 'investmentRequest' },
                required: false // Left join to include images only if they exist
            }],
            transaction
        });

        await transaction.commit();
        return updatedRequest;
    } catch (error) {
        await transaction.rollback();
        throw error;
    }
};

// Delete an investment request
const deleteInvestmentRequest = async (request_id) => {
    const transaction = await db.sequelize.transaction();

    try {
        const request = await db.InvestmentRequest.findByPk(request_id, { transaction });
        if (!request) {
            throw new Error('Investment request not found');
        }

        // Delete the request
        await db.InvestmentRequest.destroy({ where: { id: request_id }, transaction });

        await transaction.commit();
        return { message: 'Investment request deleted successfully' };
    } catch (error) {
        await transaction.rollback();
        throw error;
    }
};

// Get all investment requests
const getInvestmentRequests = async () => {
    try {
        const requests = await db.InvestmentRequest.findAll({
            include: [
                { model: db.User, as: 'user' },
                { model: db.InvestmentOffer, as: 'investmentOffers' },
                {
                    model: db.Image,
                    as: 'investment_request_images',
                    where: { entry_type: 'investmentRequest' },
                    required: false // Left join to include images only if they exist
                }
            ],
        });
        return requests;
    } catch (error) {
        throw error;
    }
};

// Get investment requests by User ID
const getInvestmentRequestsByUserId = async (user_id) => {
    try {
        const requests = await db.InvestmentRequest.findAll({
            where: { user_id },
            include: [
                { model: db.InvestmentOffer, as: 'investmentOffers' },
                {
                    model: db.Image,
                    as: 'investment_request_images',
                    where: { entry_type: 'investmentRequest' },
                    required: false // Left join to include images only if they exist
                }
            ],
        });

        if (requests.length === 0) {
            throw new Error('No investment requests found for this user');
        }

        return requests;
    } catch (error) {
        throw error;
    }
};

// Get investment request by ID
const getInvestmentRequestById = async (request_id) => {
    try {
        const request = await db.InvestmentRequest.findByPk(request_id, {
            include: [
                { model: db.User, as: 'user' },
                { model: db.InvestmentOffer, as: 'investmentOffers' },
                {
                    model: db.Image,
                    as: 'investment_request_images',
                    where: { entry_type: 'investmentRequest' },
                    required: false // Left join to include images only if they exist
                }
            ],
        });

        if (!request) {
            throw new Error('Investment request not found');
        }

        return request;
    } catch (error) {
        throw error;
    }
};

module.exports = {
    createInvestmentRequest,
    updateInvestmentRequest,
    deleteInvestmentRequest,
    getInvestmentRequests,
    getInvestmentRequestsByUserId,
    getInvestmentRequestById,
};
