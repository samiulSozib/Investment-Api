require('dotenv').config()

const express = require('express')
const cors=require('cors')



const setMiddlewares = require('./middlewares/middleware')
const setRoutes = require('./routes/routes')



const app = express()
app.use(cors({
    origin: 'http://localhost:3000', // frontend URL
    credentials: true
  }));


require('./database/db')

setMiddlewares(app)
setRoutes(app)

app.listen(1000, () => {
    console.log('server create success on port')
})